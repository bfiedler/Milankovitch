#!/usr/bin/env python
import simpleSVG, sys, math, re
startyr=200
stopyr=-200
inf=open('orbpar.txt','r')
all=inf.readlines()
years=[]
eccent=[]
obliq=[]
longit=[]
preci=[]
sinlong=[]
for i in range(6,len(all)):
	line=all[i]
	year,eccen,obli,longi=line.split()
#	print year,longi
	years.append(float(year)/1000.)
	eccenf=float(eccen)
	eccent.append(eccenf)
	obliq.append(float(obli))
	longf=float(longi)
	sinl=math.sin(math.radians(longf))
	longit.append(longf)
	sinlong.append(sinl)
	preci.append(sinl*eccenf)
#sinlong=[math.sin(math.radians(x)) for x in longit]
inf.close()
##########
inf=open('insol65.dat','r')
all=inf.readlines()
insol65=[]
for line in all:
	year,insol=line.split()
	insol65.append(float(insol))
inf.close()
##########
inf=open('insol65obliqonly.dat','r')
all=inf.readlines()
insol65o=[]
for line in all:
	year,insol=line.split()
	insol65o.append(float(insol))
print(len(insol65o),len(insol65),len(years))
inf.close()
##########
LR04=[]
LRyr=[]
inf=open('LR04stack.txt')
all=inf.readlines()
for line in all[5:]:
	yearago,d180,error=[float(x) for x in line.split()]
	LRyr.append(2.-yearago)
	LR04.append(d180)
inf.close()
###########
#inf=open('deutnat.txt')
#all=inf.readlines()
with open("deutnat.txt", "r", encoding="utf-8", errors="replace") as inf:
    all = inf.readlines()
iceyear=[]
ts=[]
for line in all[111:]:
	depth,year,deut,deltaTS=[float(x) for x  in line.split()]
	iceyear.append(2-.001*year)
	ts.append(deltaTS)
inf.close()
	
###########
b=simpleSVG.svg_class(fname='theplot.svg',bbx=1070,bby=1200)
b.scale(xmin=-800,xmax=800,ymin=0.,ymax=12.,leftmarg=85,rightmarg=85)
b.group(stroke='gray',fill='gray')
b.line(2.,0.,2.,12.)
b.group()
b.group(stroke='black',fill='black',font_size='18pt')
b.xaxis(x1=-800.,x2=800.,dx=100.,form='%5d',pad=14)
b.xaxis(x1=-800.,x2=800.,dx=100.,form='',y=12.,ticklen=-10)
b.yaxis(y1=0.,y2=12.,dy=1.,form='')
b.yaxis(y1=0.,y2=12.,dy=1.,form='',x=800.,ticklen=-10)
padl=-10.
padr=10.
padb=-.05
b.text(-800.+padl,0.+padb,0,"-4",text_anchor="end")
b.text(-800.+padl,1.+padb,0,"-2",text_anchor="end")
b.text(-800.+padl,2.+padb,0,"2",text_anchor="end")
b.text(800.+padr,2.+padb,0,"5",text_anchor="start")
b.text(800.+padr,3.+padb,0,"4",text_anchor="start")
b.text(800.+padr,4.+padb,0,"3",text_anchor="start")
b.text(-800.+padl,4.+padb,0,"400",text_anchor="end")
b.text(-800.+padl,5.+padb,0,"500",text_anchor="end")
b.text(-800.+padl,6.+padb,0,"600",text_anchor="end")
b.text(800.+padr,6.+padb,0,"-.05",text_anchor="start")
b.text(800.+padr,7.+padb,0,"0",text_anchor="start")
b.text(800.+padr,8.+padb,0,".05",text_anchor="start")
b.text(-800.+padl,8.+padb,0,"-1",text_anchor="end")
b.text(-800.+padl,9.+padb,0,"1",text_anchor="end")
b.text(800.+padr,9.+padb,0,"0",text_anchor="start")
b.text(800.+padr,10.+padb,0,".05",text_anchor="start")
b.text(-800.+padl,10.+padb,0,"21",text_anchor="end")
b.text(-800.+padl,11.+padb,0,"23",text_anchor="end")
b.text(-800.+padl,12.+padb,0,"25",text_anchor="end")
###################
xl=None
b.group(stroke='green',fill='green')
for x,y in list(zip(years,eccent))[startyr:stopyr]:
	y=y/.05 +9.
	if xl!=None: b.line(xl,yl,x,y)
	xl=x
	yl=y
#############
xl=None
b.group(stroke='blue',fill='blue')
for x,y in list(zip(years,obliq))[startyr:stopyr]:
	y=(y-23.)/2. +11.
	if xl!=None: b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
xl=None
b.group(stroke='purple',fill='purple')
for x,y in list(zip(years,sinlong))[startyr:stopyr]:
	y=.5*y+8.5
	if xl!=None: b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
xl=None
b.group(stroke='red',fill='red')
for x,y in list(zip(years,preci))[startyr:stopyr]:
	y=y/.05+7.
	if xl!=None: b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
xl=None
b.group(stroke='black',fill='black')
for x,y in list(zip(years,insol65))[startyr:stopyr]:
	y=(y-500)/100.+5.
	if xl!=None: b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
xl=None
b.group(stroke='brown',fill='brown')
for x,y in zip(LRyr,LR04):
	y=-(y-4.)+3.
	if xl!=None and x>=-800. : b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
xl=None
b.group(stroke='darkgreen',fill='darkgreen')
for x,y in zip(iceyear,ts):
	y=y/8.+1.5
	if xl!=None and x>=-800. : b.line(xl,yl,x,y)
	xl=x
	yl=y
##########
b.close()
